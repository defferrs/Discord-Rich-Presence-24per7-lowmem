RPCI LOWMEM V2

Versi ini dioptimalkan untuk hosting dengan RAM kecil.

Perubahan utama:
- Gateway intent default dipersempit menjadi GUILDS.
- Cache UserManager dibatasi.
- Cache message dan reaction dibatasi.
- Partial cache dinonaktifkan karena RPCI tidak membutuhkannya.
- Message cache memiliki lifetime/sweeper.
- Rich Presence tetap menggunakan konfigurasi yang sama.

Catatan:
Jika kamu menambahkan fitur yang membutuhkan event Discord tertentu, tambahkan intent
terkait pada config.yml bagian low_memory.intents. Untuk Rich Presence saja, biarkan
GUILDS.
